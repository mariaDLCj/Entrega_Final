
let cerrar = document.getElementById("cerrar");
let modal = document.getElementById("modal");
let aniadirBtn = document.getElementById("aniadir");
let modal_fondo = document.getElementById("modal-fondo");

// El índice va a controlar por donde va la playList
let indiceActual = 0;

aniadirBtn.addEventListener('click', cerrarAbrirModal);
cerrar.addEventListener('click', cerrarAbrirModal);

//Esta función sirve tanto para abrir como para cerrar el modal
// quita y pone el display fle o none
function cerrarAbrirModal() {
    if (modal_fondo.style.display === "none" || modal_fondo.style.display === "") {
        modal_fondo.style.display = "flex";
    } else {
        modal_fondo.style.display = "none";
    }
}

// En caso de que se haga click fuera del modal esta función lo cierra
// Hace uso del contenedor "invisible"
modal_fondo.onclick = function (event) {
    // Si donde tocas es el fondo se pone en display none
    if (event.target === modal_fondo) {
        modal_fondo.style.display = "none";
    }
};

//FIN DEL MODAL

// ------------------------------------------------------------- FUNCIONES ASINCRONAS ----------------------------------------------------
//REALIZAR EL POST
let subir = document.getElementById('subir');

async function subirCancion(event) {
    event.preventDefault();

    let titulo = document.getElementById('titulo').value;
    let autor = document.getElementById('artista').value;
    let cancion = document.getElementById('cancion').files[0];
    let portada = document.getElementById('portada').files[0];
    // Son variables que me valen para saber qué está mal de parte del user
    let autorOk = true;
    let tituloOk = true;
    let imgOk = true;
    let audioOk = true;
    let todasOk = false;

    // Regex comprueba que sea máximo de 20 letras, valen espacios en blanco
    let regex = /^[a-zA-Z\s]{1,20}$/;
    if (!regex.test(autor)) {
        autorOk = false;
        let sms = document.getElementById("smsAutor");
        sms.innerHTML = "Introduzca un nombre válido";
        sms.style.color = "red";
    } else {
        document.getElementById("smsAutor").innerHTML = "";
    }
    if (!regex.test(titulo)) {
        tituloOk = false;
        let sms = document.getElementById("smsTitulo");
        sms.innerHTML = "Introduzca un título válido";
        sms.style.color = "red";
    } else {
        document.getElementById("smsTitulo").innerHTML = "";
    }
    if (!cancion) {
        audioOk = false;
        let sms = document.getElementById("smsCancion");
        sms.innerHTML = "Introduzca un archivo .mp3";
        sms.style.color = "red";
    } else {
        document.getElementById("smsCancion").innerHTML = "";
    }
    if (!portada) {
        imgOk = false;
        let sms = document.getElementById("smsPortada");
        sms.innerHTML = "Introduzca una imagen";
        sms.style.color = "red";
    } else {
        document.getElementById("smsPortada").innerHTML = "";
    }

    // Esto es un objeto formularioDato que guarda los datos que se han obtenido del form y es lo que se pasa al post
    let formuData = new FormData();

    if (autorOk == true && tituloOk == true && audioOk == true && imgOk == true) {
        console.log(autorOk);
        console.log(tituloOk);
        console.log(audioOk);
        console.log(imgOk);

        // Se le añade la info, cuidado con el orden, si está mal no me funciona
        formuData.append('music', cancion);
        formuData.append('title', titulo);
        formuData.append('artist', autor);
        formuData.append('cover', portada);
        todasOk = true;
    }

    try {
        await fetch('http://informatica.iesalbarregas.com:7008/upload', {
            method: 'POST',
            // Se pasa para el post
            body: formuData,
        });

        // Se limpian los campos
        document.getElementById('titulo').value = "";
        document.getElementById('artista').value = "";
        document.getElementById('cancion').value = "";
        document.getElementById('portada').value = "";

        //OJO - esta función la uso para recargar la página para que la nueva canción en caso de estar cargada se muestre
        // esta info proviene de: Cómo recargar una página con JavaScript - Caronte Web Studio
        if (todasOk == true) {
            location.reload();
        }

    } catch (error) {
        console.error('Error:', error.message);
        alert('Hubo un problema al subir la canción.');
    }
};

subir.addEventListener('click', subirCancion);

// GET


// Función para obtener las canciones
async function cargarCanciones() {

    let lista = document.getElementById("lista");

    try {
        //Comprobar si la respuesta no es correcta
        const response = await fetch('http://informatica.iesalbarregas.com:7008/songs/');
        if (!response.ok) {
            let error = await response.json();
            console.error("Error al cargar las canciones", error);
        }

        //Generar todos los elementos del DOM necesarios para la tabla
        let tabla = document.getElementById("tabla");
        let filaEncabezado = document.createElement("tr");


        tabla.appendChild(filaEncabezado);
        // tabla.setAttribute("class", "mt-3 table text-white text-center ");
        //Se obtiene la lista
        let canciones = await response.json();
        //Limpiamos la lista
        lista.innerHTML = "";

        //Por cada usuario creamos una fila con sus td para las propiedades
        canciones.forEach(cancion => {
            let filaCancion = document.createElement("tr");
            let datoTitulo = document.createElement("td");
            let datoArtista = document.createElement("td");
            let datoDuracion = document.createElement("td");
            let corazon = document.createElement("buttom");
            corazon.setAttribute("id", "borrarElemento");
            // corazon.setAttribute("class", "");
            corazon.innerHTML = '<i class="fa-regular fa-heart" style="color: rgb(79, 208, 103)"></i>';
            //Cuando las funciones tienen parámetros y van por el addevent es así

         
            //Hay que crear in nuevo audio
            //para cargarlos uso el filePath que es lo que te devuelve el servidor
            let audio = new Audio(cancion.filepath);
            //Como hay que cargar los audios se meten en la función
            audio.addEventListener('loadedmetadata', () => {            
                //  Hay que calcular cuantos minutso y segundos duran
                // recorda que toFixed para que nos de los 2 decimales, formatea 
                //Pd: no se lo he copiado a Félix >:c
                let duracion = audio.duration.toFixed(2);
                let minutos = Math.floor(duracion / 60);
                let segundos = Math.floor(duracion % 60);
                //Para mostralo en caso de que sólo hay un número en los decimales se añade un 0 delante
                let minutosTotales= `${minutos}:${segundos < 10 ? '0' : ''}${segundos}`;
                datoDuracion.innerHTML=minutosTotales;
            });

            corazon.addEventListener('click', () => favoritas(cancion));
            datoTitulo.setAttribute("class", "tds");
            datoArtista.setAttribute("class", "tds");
            datoDuracion.setAttribute("class", "tds");
            corazon.setAttribute("class", "corazon");
            filaCancion.setAttribute("class", "fila");
            //Le asigno los valores a los datos de la tabla
            datoTitulo.textContent = cancion.title;
            datoArtista.textContent = cancion.artist;
            //Los añado
            filaCancion.append(datoTitulo, datoArtista, datoDuracion, corazon);
            tabla.appendChild(filaCancion);

            //Al pulsar dos veces sobre un afila haces play en la concion
            filaCancion.addEventListener('click', () => seleccionarCancion(cancion));

            
        //Generar un hover con el id en el css 
        filaCancion.setAttribute("id", "filaCancion");

            //Se mete la canción en la playList
            sonido.playList.push(cancion);
        });

        let todosBoton = document.getElementById("todos");
        let favsBoton = document.getElementById("favoritos");

        favsBoton.addEventListener('click', mostrarLocalStorage);
        todosBoton.addEventListener('click', cargarCanciones);
        //----------------------------ASIGNACIÓN DE FUNCIONES-------------------
        //Obtención de los botones
        let audio = document.getElementById('audioCancion');
        //Esta función hace que la barra de progreso del audio se vaya moviendo
        audio.addEventListener('timeupdate', moverBarra);

        let onOff = document.getElementById("onOff");
        //Es el playPause pero del botón verde esquina superior derecha
        onOff.addEventListener('click', funcionPausePlay);

        let playPauseBoton = document.getElementById("playPauseBoton");
        playPauseBoton.addEventListener('click', funcionPausePlay);

        let loopBoton = document.getElementById("loopBoton");
        loopBoton.addEventListener('click', repetirCancion);

        //FUNCIONES DE AUDIO SELECCIONADO

        let shuffleBoton = document.getElementById("shuffleBoton");
        shuffleBoton.addEventListener('click', funcionShuffle);


        let previoBoton = document.getElementById("previoBoton");
        previoBoton.addEventListener('click', funcionPrevia);

        let siguienteBoton = document.getElementById("siguienteBoton");
        siguienteBoton.addEventListener('click', siguiente);

        let barraProgreso = document.getElementById("barra-progreso");
        barraProgreso.addEventListener('click', (event) => {
            tocarBarra(event, barraProgreso)
        });

        let barraVolumen = document.getElementById('barra-volumen');
        barraVolumen.addEventListener('click', ajustarVolumen);

        lista.innerHTML = "";
        lista.appendChild(tabla);
    } catch (e) {
        console.error("Error al cargar canciones:", e);
    }
}

cargarCanciones();

// -------------------------------------------- MANEJAR LOS AUDIOS ------------------------------------------------------------

let audio = document.getElementById("audioCancion");

//En vez de declarar 4 variables globales declaro un objeto, igual es peor, pero es un intento
let sonido = {
    hayLoop: false,
    hayShuffle: false,
    sonando: false,
    playList: [],
};

//Mueve la barrita del progreso
function moverBarra() {
    let progreso = document.getElementById('progreso');
    let duracion = audio.duration;
    let tiempoActual = audio.currentTime;
    let anchoProgreso = (tiempoActual / duracion) * 100;
    progreso.style.width = anchoProgreso + '%';

    //Modifico los minutos que se ven en la barra
    //Es necesario comprobar que si están a 0 por no haber canción elegida ponga 0 y no Nan
    if (duracion == 0.0 || tiempoActual == 0.0) {
        document.getElementById('duracion').textContent = "00:00";
    } else {
        document.getElementById('duracion').textContent = formateado(duracion);
    }
    document.getElementById('tiempo-actual').textContent = formateado(tiempoActual);
}

//Es igual ara las dos, así no se repite tanto codigo
function formateado(segundos) {
    let minutos = Math.floor(segundos / 60);
    let segundosRestantes = Math.floor(segundos % 60);
    return `${minutos < 10 ? '0' + minutos : minutos}:${segundosRestantes < 10 ? '0' + segundosRestantes : segundosRestantes}`;
}

setInterval(moverBarra, 100);

//Esta función registra donde se toca de la barra de progreso y modifica el tiempo del audio para que se actualice en función
function tocarBarra(event, barraProgreso) {

    //Donde se toca con el click
    let selecionado = event.offsetX;
    // El tamaño que tiene la barra entera
    let totalBarra = barraProgreso.offsetWidth;

    // Para calcular el porcentaje de la barra donde se hizo clikc
    let porcentaje = (selecionado / totalBarra) * 100;

    // Ajustar el tiempo del audio según el porcentaje
    let nuevoActual = (audio.duration * porcentaje) / 100;
    audio.currentTime = nuevoActual;
}

//Función cuando pulsas en la canción salta el play
function seleccionarCancion(cancion) {

    //Si se encuentra la cancón que ha sido clickada el indice se pone en esa posición
    //De esta manera se actualiza el índice y las funciones de siguiente y previo pueden ejecutarse sobre el 
    //indice correcto
    for (let i = 0; i < sonido.playList.length; i++) {
        if (cancion === sonido.playList[i]) {
            indiceActual = i;
        }
    }

    //Se obtienen el audio del html
    console.log("Canción seleccionada:", cancion);
    //LE asigno al audio del html el src del que audio seleccionado por el user
    audio.src = cancion.filepath;
    // Activamo el autoplay
    audio.play();
    //Pongo la variable que sonando a true, para que el botópn de playPause se actualice correctamente el el html
    sonido.sonando = true;

    //Para que el volumen empiece a la mitad
    audio.volume = 0.5;
    //En el html el botón de play está por defecto y al pulsar una canión e iniciarse
    //este botón debe cambiar automáticamente, por lo que corresponde a esta función
    //Al pararlo  volver a iniciarlo se cambia en el evento asignado al clik de ese botón
    playPauseBoton.innerHTML = '<i class="fa-regular fa-circle-pause"></i>';
    // playPauseBoton.classList.add
    let fondo = document.getElementById("imgCover");
    fondo.src = cancion.cover;

    //Poner nombre autor y titulo en html
    let artistaDom = document.getElementById("artistaCancion");
    let tituloDom = document.getElementById("tituloCancion");

    // artistaDom.classList.add("texto");
    // tituloDom.classList.add("texto");
    tituloDom.innerHTML = cancion.title;
    artistaDom.innerHTML = cancion.artist;

}

//Esta función cambia en ambos botones de playPAuse 
function funcionPausePlay() {
    if (sonido.sonando) {
        audio.pause();
        onOff.innerHTML = 'PLAY';
        playPauseBoton.innerHTML = '<i class="fa-regular fa-circle-play"></i>';
    } else {
        audio.play();
        onOff.innerHTML = 'PAUSE';
        playPauseBoton.innerHTML = '<i class="fa-regular fa-circle-pause"></i>';
    }
    sonido.sonando = !sonido.sonando;
}

// Loopea las canciones para que se repitan
function repetirCancion() {
    //Invirto el valor que tenían anteriormente si era true ahora es false
    sonido.hayLoop = !sonido.hayLoop;
    //Le pongo el valor a la propiedad del audio
    audio.loop = sonido.hayLoop;
    //En caso de que el loop haya sido marcado pues sufle debe desmarcarse
    if (sonido.hayLoop == true) {
        sonido.hayShuffle = false;
        // shuffleBoton.style.backgroundColor = "";
        shuffleBoton.classList.remove("activo");
        loopBoton.classList.add("activo");

    } else {
        loopBoton.classList.remove("activo");
    }

}

//Se desordena con el método de fisher Yates
function desordenar(lista) {
    for (let i = lista.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [lista[i], lista[j]] = [lista[j], lista[i]];
    }
    return lista;
}

function funcionShuffle() {
    //Invirto el valor que tenían anteriormente si era true ahora es false
    sonido.hayShuffle = !sonido.hayShuffle;
    if (sonido.hayShuffle == true) {
        //Si el shufle está on se quita el loop
        audio.loop = false;
        sonido.hayLoop = false;
        loopBoton.classList.remove("activo");
        shuffleBoton.classList.add("activo");
        // Se mezclan las canciones de la playlist
        sonido.playList = desordenar(sonido.playList);
    }else{
        shuffleBoton.classList.remove("activo");
    }
};

// Cuando se termine llama a la siguiente
audio.addEventListener('ended', siguiente);

function siguiente() {

    //Al indice le ponemos uno para avanzar
    indiceActual++;
    if (indiceActual >= sonido.playList.length) {
        // En caso de que llegue a un indice que supera la longitud de las canciones se vuelve al inciio
        indiceActual = 0;
    }
    seleccionarCancion(sonido.playList[indiceActual]);

}

function funcionPrevia() {
    //Al indice le quitamos uno para retroceder
    indiceActual--;
    if (indiceActual < 0) {
        // En caso de que llegue a valores negativos como el array empeiza en 0 vuelve al final
        indiceActual = sonido.playList.length - 1;
    }
    seleccionarCancion(sonido.playList[indiceActual]);
}

//Función para manejar e volumen funciona parecida al progreso
//Según https://www.w3schools.com/tags/av_prop_volume.asp el volumen va de 0 a 1
function ajustarVolumen(event) {
    //En esste caso la barra de volumen es un input en el html
    // así que se recoge su valor
    let valorVolumen = event.target.value;
    // como el volumen del audio va de 1 en uno hay que dividir para que funcione
    audio.volume = valorVolumen / 100;
}

//Recordatorio Personal: el manejo del localStorage está en Actividad_LocalStorage
function favoritas(cancion) {
    /*
    El funcionamiento de esta función consiste en: buscar si la canción existe en localStorage
    En caso de que sí exista, se elimina y sii no existe, se añade
    */

    // Variable de control
    let encontrada = false;
    //No funciona
    let corazon = document.getElementById("corazon");
    //Traemos el corazón para cambiarle el icono
    // Se recorre en busca de la canción en el localStorage
    for (let index = 0; index < localStorage.length; index++) {
        let clave = localStorage.key(index);
        if (cancion.id == clave) {
            encontrada = true;
            break;
        }
    }

    // Si la canción ha sido encontrada es que ya existe, así que se elimina
    if (encontrada) {
        localStorage.removeItem(cancion.id);
        console.log("Canción eliminada de favs");
        corazon.classList.add("fa-regular fa-heart");
    } else {
        // Si no está, es que no existe y se añade
        localStorage.setItem(cancion.id, JSON.stringify(cancion));
        console.log("Canción añadida a favs");
        corazon.classList.add("fa-solid fa-heart");
    }
    console.log(localStorage);
}

/*Esta función va a sustituir la lista que aparece automáticamente de servidor 
por la del localStorage  va a ser llamada en cargarCanciones

IMPORTANTE PROFESOR/A: Sí actualiza las canciones cuando le das al corazón en función del valor que tengan
pero tienes que darle a todos y luego a favoritos para que se vea la que acabas de quitar de favoritos
*/
function mostrarLocalStorage() {

    let lista = document.getElementById("lista");
    let tabla = document.getElementById("tabla");
    lista.innerHTML = "";
    tabla.innerHTML = "";

    //1º HAy que obtener todas las canciones que están guardadas en el Local pero están en texto
    let canciones = [];

    // Se recorre todo el local
    for (let index = 0; index < localStorage.length; index++) {
        //Se obtiene de nuevo la clave para poder acceder a la canción
        let clave = localStorage.key(index);
        //Mediante la clave se accede al valir, es decir la canción
        let cancion = localStorage.getItem(clave);

        //Por último hay que convertir el de un json a objeto y meterla en la lista
        canciones.push(JSON.parse(cancion));
    }

    //Y ahora sí se puede hacer lo demás
    //Por cada usuario creamos una fila con sus td para las propiedades
    canciones.forEach(cancion => {
        let filaCancion = document.createElement("tr");
        let datoTitulo = document.createElement("td");
        let datoArtista = document.createElement("td");
        let datoDuracion = document.createElement("td");
        let corazon = document.createElement("buttom");
        corazon.setAttribute("id", "borrarElemento");
        // corazon.setAttribute("class", "");
        corazon.classList.add("fa-regular fa-heart");
        //Cuando las funciones tienen parámetros y van por el addevent es así

     
        //Hay que crear in nuevo audio
        //para cargarlos uso el filePath que es lo que te devuelve el servidor
        let audio = new Audio(cancion.filepath);
        //Como hay que cargar los audios se meten en la función
        audio.addEventListener('loadedmetadata', () => {            
            //  Hay que calcular cuantos minutso y segundos duran
            // recorda que toFixed para que nos de los 2 decimales, formatea 
            //Pd: no se lo he copiado a Félix >:c
            let duracion = audio.duration.toFixed(2);
            let minutos = Math.floor(duracion / 60);
            let segundos = Math.floor(duracion % 60);
            //Para mostralo en caso de que sólo hay un número en los decimales se añade un 0 delante
            let minutosTotales= `${minutos}:${segundos < 10 ? '0' : ''}${segundos}`;
            datoDuracion.innerHTML=minutosTotales;
        });

        corazon.addEventListener('click', () => favoritas(cancion));
        datoTitulo.setAttribute("class", "tds");
        datoArtista.setAttribute("class", "tds");
        datoDuracion.setAttribute("class", "tds");
        corazon.setAttribute("class", "corazon");
        filaCancion.setAttribute("class", "fila");
        //Le asigno los valores a los datos de la tabla
        datoTitulo.textContent = cancion.title;
        datoArtista.textContent = cancion.artist;
        //Los añado
        filaCancion.append(datoTitulo, datoArtista, datoDuracion, corazon);
        tabla.appendChild(filaCancion);


        //Generar un hover con el id en el css 
        filaCancion.setAttribute("id", "filaCancion");

        //Al pulsar dos veces sobre un afila haces play en la concion
        filaCancion.addEventListener('click', () => seleccionarCancion(cancion));


        //Se mete la canción en la playList
        sonido.playList.push(cancion);
    });

    lista.innerHTML = "";
    lista.appendChild(tabla);
}

// Esta función simplemente cambia el icono en función de los puntos asignados por el input
let volumen = document.getElementById("volumen");
volumen.addEventListener('input', () => {
    let icono = document.getElementById("icono-Audio");

    if (volumen.value == 0) {
        icono.className = "fa-solid fa-volume-xmark";
    } else if (volumen.value == 100) {
        icono.className = "fa-solid fa-volume-high";
    } else {
        icono.className = "fa-solid fa-volume-low";
    }
});